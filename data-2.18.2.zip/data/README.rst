Included Data
=============

This directory provides an empty GeoServer data directory, as such this directory
does not contain any published data and is not subject to a data license.